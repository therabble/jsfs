module.exports = {
	STORAGE_LOCATIONS:[
		{
      storage:"linode-object-storage",
      path:"blocks6/", //not a 'real' path obvs., but must be unique.
      status:"mirror"
      // config: { //this would be neet for multi-backed jsfs
      //   ENDPOINT: "us-east-1.linodeobjects.com", //Newark NJ
      //   BUCKET: "rabble-dev-scratch",
      //   AUTHENTICATION: {
      //     ACCESS_KEY_ID: "akeyid",
      //     SECRET_ACCESS_KEY: "asecret",
      //   },
      //   BLOCK_SIZE: 1048576
      // }
    },
    {
      storage:"fs",
      path:"./blocks3/", //ordered before mothballed so reads find stuff here first
      status:"balanced"
      // config: {
      //   BLOCK_SIZE: 1048576
      // }
    },
    {
      storage:"fs",
      path:"./blocks4/", //ordered before mothballed so reads find stuff here first
      status:"balanced"
      // config: {
      //   BLOCK_SIZE: 1048576
      // }
    },
    {
      storage:"fs",
      path:"./blocks5/", //ordered before mothballed so reads find stuff here first
      status:"balanced"
      // config: {
      //   BLOCK_SIZE: 1048576
      // }
    },
    {
      storage:"fs",
      path:"./blocks1/",
      status:"mothballed"
      // config: {
      //   BLOCK_SIZE: 1048576
      // }
    },
		{
      storage:"fs",
      path:"./blocks2/",
      status:"mothballed"
      // config: {
      //   BLOCK_SIZE: 1048576
      // }
    }
	], //at least one entry is required or JSFS won't look for a resource, it can be {"path":""}
	BLOCK_SIZE: 1048576,
  MINIMUM_BALANCED_LOCATIONS_FOR_A_BLOCK: 2,  //mirror storage locations get all writes, mothballed sites won't be considered at all.
  STORAGE_INDEX_FOR_NEW_LAST_SEEN_PATHS: 0,  // When a new last seen is created
    // setting this to -1 will record last written location instead
    // as set with 0, it will now point at the first Storage Location (currently a linode mirror)
	LOG_LEVEL: 0,
	SERVER_PORT: 7302,
	REQUEST_TIMEOUT: 30, // minutes
	// CONFIGURED_STORAGE: "linode-object-storage", //deprecated by plural storage
  LINODE_OBJECT_STORAGE: {
    ENDPOINT: "us-east-1.linodeobjects.com", //Newark NJ
    BUCKET: "rabble-dev-scratch",
    AUTHENTICATION: {
      ACCESS_KEY_ID: "E2SU7MLA0WMYSHJPQHJY",
      SECRET_ACCESS_KEY: "OwK5LQipLxmMTWlCGsoikVPgyrQcc70wseUXPymK",
    }
  }
};
